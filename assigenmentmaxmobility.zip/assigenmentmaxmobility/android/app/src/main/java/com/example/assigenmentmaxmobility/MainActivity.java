package com.example.assigenmentmaxmobility;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
