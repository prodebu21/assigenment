import 'dart:io';

import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:url_launcher/url_launcher.dart';
import '../helper/databasehelper.dart';
import 'consumeradd.dart';


class ListingPage extends StatefulWidget {
  const ListingPage({super.key});

  @override
  _ListingPageState createState() => _ListingPageState();
}

class _ListingPageState extends State<ListingPage> {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<List<Map<String, dynamic>>> _fetchCustomers() async {
    try {
      return await _dbHelper.getCustomers();
    } catch (e) {
      print('Error fetching customers: $e');
      return [];
    }
  }

  Future<void> _openMap(double lat, double long) async {
    final Uri googleMapsUri = Uri.parse('geo:$lat,$long');

    try {
      if (await canLaunchUrl(googleMapsUri)) {
        await launchUrl(googleMapsUri);
      } else {
        print('Could not launch $googleMapsUri');
        throw 'Could not launch $googleMapsUri';
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  Future<void> _refreshList() async {
    setState(() {
      // Refresh the list by re-fetching the customers
      _fetchCustomers();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Customer Listing'),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _fetchCustomers(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No customers found.'));
          } else {
            final customers = snapshot.data!;
            return RefreshIndicator(
              onRefresh: _refreshList,
              child: ListView.builder(
                itemCount: customers.length,
                itemBuilder: (context, index) {
                  final customer = customers[index];
                  return Card(
                    margin: const EdgeInsets.all(8.0),
                    elevation: 5,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          customer['image'] != null
                              ? Image.file(
                            File(customer['image']),
                            width: 70,
                            height: 70,
                            fit: BoxFit.cover,
                          )
                              : const SizedBox.shrink(),
                          const SizedBox(height: 8.0),
                          Text(
                            'Full Name: ${customer['full_name'] ?? 'N/A'}',
                            style: const TextStyle(
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4.0),
                          Text(
                            'Mobile No: ${customer['mobile_no'] ?? 'N/A'}',
                            style: const TextStyle(
                              fontSize: 16.0,
                            ),
                          ),
                          const SizedBox(height: 4.0),
                          Text(
                            'Email: ${customer['email'] ?? 'N/A'}',
                            style: const TextStyle(
                              fontSize: 16.0,
                            ),
                          ),
                          const SizedBox(height: 4.0),
                          Text(
                            'Address: ${customer['address'] ?? 'N/A'}',
                            style: const TextStyle(
                              fontSize: 16.0,
                            ),
                          ),
                          const SizedBox(height: 4.0),
                          Text(
                            'Latitude: ${customer['lat']?.toString() ?? 'N/A'}',
                            style: const TextStyle(
                              fontSize: 16.0,
                            ),
                          ),
                          const SizedBox(height: 4.0),
                          Text(
                            'Longitude: ${customer['long']?.toString() ?? 'N/A'}',
                            style: const TextStyle(
                              fontSize: 16.0,
                            ),
                          ),
                          const SizedBox(height: 4.0),
                          Text(
                            'Geo Address: ${customer['geo_address'] ?? 'N/A'}',
                            style: const TextStyle(
                              fontSize: 16.0,
                            ),
                          ),
                          const SizedBox(height: 16.0),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(
                              icon: const Icon(Icons.map),
                              onPressed: () {
                                final latitude = customer['lat'] as double?;
                                final longitude = customer['long'] as double?;
                                if (latitude != null && longitude != null) {
                                  _openMap(latitude, longitude);
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const Consumeradd()),
          );
          if (result == true) {
            _refreshList();
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
