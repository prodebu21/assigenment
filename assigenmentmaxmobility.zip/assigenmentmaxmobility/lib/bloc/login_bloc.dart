// login_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';

import '../helper/databasehelper.dart';

// Define the events
abstract class LoginEvent {}

class LoginButtonPressed extends LoginEvent {
  final String userId;
  final String password;

  LoginButtonPressed(this.userId, this.password);
}

// Define the states
abstract class LoginState {}

class LoginInitial extends LoginState {}

class LoginLoading extends LoginState {}

class LoginSuccess extends LoginState {}

class LoginFailure extends LoginState {
  final String error;

  LoginFailure(this.error);
}

// BLoC class
class LoginBloc extends Bloc<LoginEvent, LoginState> {
  LoginBloc() : super(LoginInitial()) {
    on<LoginButtonPressed>((event, emit) async {
      emit(LoginLoading());

      // Simulate a delay
      await Future.delayed(Duration(seconds: 1));

      if (event.userId == 'user@maxmobility.in' && event.password == 'Abc@#123') {
        // On successful login, insert customer data if not already present
        emit(LoginSuccess());
      } else {
        emit(LoginFailure('Invalid user ID or password'));
      }
    });
  }
}
