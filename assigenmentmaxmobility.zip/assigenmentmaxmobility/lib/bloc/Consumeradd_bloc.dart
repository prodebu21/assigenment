import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../helper/databasehelper.dart';
 // Import your database helper class

// Define your Bloc states
abstract class ConsumerState {}

class InitialState extends ConsumerState {}

class ImagePickedState extends ConsumerState {
  final XFile image;
  ImagePickedState(this.image);
}

class FormSuccessState extends ConsumerState {}

class FormErrorState extends ConsumerState {
  final String message;
  FormErrorState(this.message);
}

class LocationRetrievedState extends ConsumerState {
  final double latitude;
  final double longitude;
  final String geoAddress;

  LocationRetrievedState(this.latitude, this.longitude, this.geoAddress);
}

// Define your Bloc events
abstract class ConsumerEvent {}

class PickImageEvent extends ConsumerEvent {}

class SubmitFormEvent extends ConsumerEvent {
  final Map<String, dynamic> customerData;

  SubmitFormEvent(this.customerData);
}

class GetLocationEvent extends ConsumerEvent {}

// Implement your Bloc
class ConsumerBloc extends Bloc<ConsumerEvent, ConsumerState> {
  final DatabaseHelper _dbHelper = DatabaseHelper(); // Initialize database helper

  ConsumerBloc() : super(InitialState()) {
    on<PickImageEvent>(_onPickImage);
    on<SubmitFormEvent>(_onSubmitForm);
    on<GetLocationEvent>(_onGetLocation);
  }

  Future<void> _onPickImage(PickImageEvent event, Emitter<ConsumerState> emit) async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      emit(ImagePickedState(image));
    } else {
      emit(FormErrorState("Failed to pick image"));
    }
  }

  Future<void> _onSubmitForm(SubmitFormEvent event, Emitter<ConsumerState> emit) async {
    try {
      await _dbHelper.insertCustomer(event.customerData); // Save to database
      emit(FormSuccessState());
    } catch (e) {
      emit(FormErrorState("Failed to submit form: $e"));
    }
  }

  Future<void> _onGetLocation(GetLocationEvent event, Emitter<ConsumerState> emit) async {
    // Implement location retrieval logic here
  }
}
