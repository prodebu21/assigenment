import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class MapUtils {
  MapUtils._();

  // Function to open Google Maps with latitude and longitude
  static Future<void> openMap(double latitude, double longitude) async {
    final Uri googleMapsUri = Uri.parse(
        'geo:$latitude,$longitude'); // Use geo scheme to open map directly

    if (await canLaunchUrl(googleMapsUri)) {
      await launchUrl(googleMapsUri);
    } else {
      throw 'Could not open the map.';
    }
  }
}

class ListingPage extends StatelessWidget {
  const ListingPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Example latitude and longitude
    final double latitude = 22.8817562;
    final double longitude = 87.9795681;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Open Map Example'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            try {
              await MapUtils.openMap(latitude, longitude);
            } catch (e) {
              print('Error: $e');
            }
          },
          child: const Text('Open Map'),
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: ListingPage(),
  ));
}
